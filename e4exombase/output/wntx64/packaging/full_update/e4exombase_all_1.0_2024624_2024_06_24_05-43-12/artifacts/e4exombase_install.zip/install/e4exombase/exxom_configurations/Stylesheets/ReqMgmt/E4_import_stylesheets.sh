#!/bin/bash

cd $TC_BIN
./install_xml_stylesheet_datasets -u=infodba -p=yGaHhvC3N0K02VqE -g=dba -input=$TC_INSTALL_DIR/e4exombase/exxom_configurations/Stylesheets/AWC/E4_import_awc_stylesheet_input.dat -filepath=$TC_INSTALL_DIR/e4exombase/exxom_configurations/Stylesheets/AWC -replace