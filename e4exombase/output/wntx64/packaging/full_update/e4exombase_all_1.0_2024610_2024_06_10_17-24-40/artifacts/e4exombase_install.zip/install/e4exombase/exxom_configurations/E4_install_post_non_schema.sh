#!/bin/bash

#command to Import Preferences
. ${TC_INSTALL_DIR}/e4exombase/exxom_configurations/Preferences/E4_import_preferences.sh

#command to Import Preferences
. ${TC_INSTALL_DIR}/e4exombase/exxom_configurations/Stylesheets/AWC/E4_import_awc_stylesheets.sh