#!/bin/bash

#command to Import Preferences
cd $TC_INSTALL_DIR/e4exombase/exxom_configurations/Preferences
. E4_import_preferences.sh

cd $TC_INSTALL_DIR/e4exombase/exxom_configurations/Stylesheets/AWC
. E4_import_stylesheets.sh